<?php
  header("Cache-Control: no-store, no-cache, must-revalidate");
  header("Expires: " . date("r"));

  function minify($html){
    $search = array(
      '/\>[^\S ]+/s',     // strip whitespaces after tags, except space
      '/[^\S ]+\</s',     // strip whitespaces before tags, except space
      '/(\s)+/s',         // shorten multiple whitespace sequences
      '/<!--(.|\s)*?-->/' // Remove HTML comments
    );

    $replace = array(
      '>',
      '<',
      '\\1',
      ''
    );

    return str_replace('> <', '><', preg_replace($search, $replace, $html));
  };

  ob_start('minify');
?>
<!DOCTYPE html>
<html lang="ru" ng-app="app">
  <head>
    <base href="/" />

    <title id="title"></title>

    <link href="/css/fonts.css" rel="stylesheet" type="text/css" />
    <link href="/css/base.css" rel="stylesheet" type="text/css" />
    <link href="/css/header.css" rel="stylesheet" type="text/css" />
    <link href="/css/ui.css" rel="stylesheet" type="text/css" />

    <link href="/css/guide.css" rel="stylesheet" type="text/css" />

    <script src="/js/dictionary.js"></script>

    <script src="/js/angular/main.js"></script>
    <script src="/js/angular/route.js"></script>

    <script src="/js/app/main.js"></script>
    <!-- <script src="/js/app/menu.js"></script> -->
    <script src="/js/app/body.js"></script>
    <!-- <script src="/js/app/controller/guide.js"></script> -->
  </head>
  <body id="body">

    <header id="header">
      <div class="row">
        <div class="logo line col-1">
          <a href="/" class="text">logotype</a>
        </div>

        <nav class="nav line col-2">
          <a class="link"></a>
        </nav>

        <div class="navigation line col-1">
          <div class="login-link">
            <span class="text sign-up" onclick="modal.open('sign-up')"></span>
            <span class="text sign-in" onclick="modal.open('sign-in')"></span>
          </div>

          <div class="lang-dropdown">
            <div class="options">
              <i class="icon icon-translate"></i>
              <span class="lang"></span>
              <a href="/en" class="lang"></a>
              <a href="/kz" class="lang"></a>
            </div>
          </div>
        </div>
      </div>
    </header>

    <div id="content"></div>

  </body>
</html>
<?php ob_end_flush(); ?>
