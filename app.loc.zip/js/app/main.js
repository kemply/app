"use strict";
!function(){
  var A = angular.module("app", [inc.route]);
  var D = { push : function(k,v){
    if( typeof k == "object" )
      for(v in k) this[v] = k[v];
    else this[k] = v;

    return this
  }};

  function onurl(u,c){
    if( !D.CGI )
      D.push("CGI", A.config([
        inc.provider.route,
        inc.provider.location,
        function(r, l){
          l.html5Mode({
            enabled     : true,
            requireBase : false
          });

          D.push("CGU", r.when)
        }
      ]));

    D.CGU(u, c)
  }

  window.app = {
    module      : A.module,
    controller  : A.controller,
    onurl       : onurl
  }
}();
