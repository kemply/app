"use strict";

// app.onurl("/", {
//   redirectTo : "/guide"
// });
