"use strict";
!function(){
  var menu = function(){

    this.signUp = "Регистрация";
    this.signIn = "Войти";
  }

  app.controller("menu", menu);
}();
