"use strict";
!function(){
  var i = { push : function(k,v){
    if( typeof k == "object" )
      for(v in k) this[v] = k[v];
    else this[k] = v;

    return this
  }};

  window.inc = i.push({
    route     : "ngRoute",
    provider  : {
      route     : "$routeProvider",
      location  :"$locationProvider"
    }
  })
}()
